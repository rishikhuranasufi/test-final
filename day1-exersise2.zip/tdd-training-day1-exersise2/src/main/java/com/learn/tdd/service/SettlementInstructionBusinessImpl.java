package com.learn.tdd.service;

import com.learn.tdd.vo.SettlementInstruction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component(value = "settlementInstructionBusinessImpl")
public class SettlementInstructionBusinessImpl {

    private static final Logger logger = LoggerFactory.getLogger(SettlementInstructionBusinessImpl.class);

    public Boolean validate(SettlementInstruction settlementInstruction) {

        if(StringUtils.isEmpty(settlementInstruction.getFutureEffectiveSICOntroller().equals("")))
            return Boolean.FALSE;
        return null;
        //9702502
    }
}
